# DupeClient 1.0 — Fabric 1.21.11 (Việt hóa)

Mod thử nghiệm dành cho thế giới/server riêng.

## Cách dùng
- Nhấn **J** để mở menu.
- Cầm vật phẩm và chọn **Nhân bản vật phẩm đang cầm vào ô trống**.
- Chỉ gửi yêu cầu sao chép bằng gói Creative thông thường của Minecraft.
- Máy chủ vẫn là bên quyết định chấp nhận hay từ chối.

## Giới hạn
- Không phải công cụ vượt Anti-Dupe.
- Không tạo vật phẩm trong Sinh tồn.
- Không thể ép máy chủ khác chấp nhận thay đổi túi đồ.
- Chỉ dùng để thử nghiệm trên thế giới/server riêng có quyền Creative.

## Biên dịch
Cần Java 21 và Gradle 8.12 trở lên, cùng kết nối mạng để Gradle tải các thư viện Fabric/Minecraft.

Trong thư mục dự án chạy:

```bash
gradle build
```

File mod sau khi biên dịch dự kiến nằm tại `build/libs/dupeclient-1.0.0.jar`.

**Lưu ý:** Gói ZIP này là mã nguồn, chưa phải file JAR đã biên dịch.
