package dev.example.dupeclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundSetCreativeModeSlotPacket;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public final class DupeScreen extends Screen {
    public DupeScreen() {
        super(Component.literal("DupeClient - Công cụ thế giới riêng"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        this.addRenderableWidget(Button.builder(
                Component.literal("Nhân bản vật phẩm đang cầm vào ô trống"),
                button -> copyHeldItem()
        ).bounds(centerX - 105, centerY - 10, 210, 24).build());

        this.addRenderableWidget(Button.builder(
                Component.literal("Đóng"),
                button -> this.onĐóng()
        ).bounds(centerX - 45, centerY + 24, 90, 20).build());
    }

    private void copyHeldItem() {
        Minecraft minecraft = Minecraft.getInstance();
        Player player = minecraft.player;

        if (player == null || minecraft.getConnection() == null) {
            DupeClient.notifyPlayer("Không tìm thấy người chơi hoặc kết nối máy chủ.");
            return;
        }

        // This uses Minecraft's normal creative-inventory packet.
        // The server remains authoritative and rejects it outside Creative mode
        // or when its own permissions/rules do not allow the action.
        if (!player.getAbilities().instabuild) {
            DupeClient.notifyPlayer("Cần bật Sáng tạo. Mod không vượt qua hệ thống bảo vệ của máy chủ.");
            return;
        }

        ItemStack held = player.getMainHandItem();
        if (held.isEmpty()) {
            DupeClient.notifyPlayer("Hãy cầm một vật phẩm trước.");
            return;
        }

        Inventory inventory = player.getInventory();
        int targetMenuSlot = -1;

        // Player inventory menu hotbar slots are 36 through 44.
        for (int hotbarIndex = 0; hotbarIndex < 9; hotbarIndex++) {
            if (inventory.getItem(hotbarIndex).isEmpty()) {
                targetMenuSlot = 36 + hotbarIndex;
                break;
            }
        }

        if (targetMenuSlot == -1) {
            DupeClient.notifyPlayer("Thanh công cụ không còn ô trống.");
            return;
        }

        minecraft.getConnection().send(
                new ServerboundSetCreativeModeSlotPacket(targetMenuSlot, held.copy())
        );
        DupeClient.notifyPlayer("Đã gửi yêu cầu sao chép. Máy chủ quyết định có chấp nhận hay không.");
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        super.render(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 55, 0xFFFFFF);
        graphics.drawCenteredString(this.font,
                "Chỉ dùng ở chế độ Sáng tạo • máy chủ quyết định • thử nghiệm riêng",
                this.width / 2, this.height / 2 - 35, 0xAAAAAA);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
